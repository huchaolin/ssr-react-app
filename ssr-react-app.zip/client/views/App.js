import React, { Component } from 'react'; //    eslint-disable-line
import { hot } from 'react-hot-loader';//   eslint-disable-line 
import { Route, Redirect } from 'react-router-dom';
import { Layout } from 'antd';
import TopicList from './topic-list';
import TopicDetails from './topic-details';
import TopBar from './component/TopBar';
import User from './user/index';
import Login from './login/index';
import createTopic from './create-topic/index';
import './App.css';

const {
  Header, Footer, Content,
} = Layout;

class App extends Component {
  render() {
    return (
         <Layout>
            <Header>
                <TopBar />
            </Header>
            <Content>
                <Route path="/" render={() => <Redirect to="/list" />} exact />
                <Route path="/list" component={TopicList} exact />
                <Route path="/topic-details/:id" component={TopicDetails} />
                <Route path="/user" component={User} />
                <Route path="/login" component={Login} />
                <Route path="/create-topic" component={createTopic} />
            </Content>
            <Footer />
         </Layout>
    );
  }
};
// const App = () => (
// <div>
//     <span>首页</span>
//     <Route path="/" render={() => <Redirect to="/list" />} exact />
//     <Route path="/list" component={TopicList} exact />
//     <Route path="/topic-details" component={TopicDetails} />
// </div>
// );


export default hot(module)(App);
